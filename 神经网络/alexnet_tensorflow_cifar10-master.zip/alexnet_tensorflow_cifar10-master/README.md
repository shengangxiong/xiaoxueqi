####################################################
# python 2.7
###################################################

#for train
python training.py -train
#for test
python training.py -test

