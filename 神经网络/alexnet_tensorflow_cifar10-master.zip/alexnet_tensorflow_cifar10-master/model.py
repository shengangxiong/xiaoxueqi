
# -*- coding: utf-8 -*-

import tensorflow as tf
def inference(images, batch_size, n_classes):   # 定义AlexNet网络的结构
    # 卷积层conv1
    with tf.variable_scope('conv1_lrn') as scope:  
		# 定义权值并初始化
		weights = tf.get_variable('weights', shape= [5, 5, 3, 64], dtype= tf.float32,
		initializer= tf.truncated_normal_initializer(stddev= 0.01, dtype= tf.float32))
		# 定义偏执并初始化
		biases = tf.get_variable('biases', shape= [64], dtype= tf.float32, initializer=
		tf.constant_initializer(0.0))
		# 卷积运算
		conv = tf.nn.conv2d(images, weights, strides= [1,1,1,1], padding= 'SAME')
		print ("input img shape %s"%(images.shape))
		print ("conv1 img shape %s"%(conv.shape))
		pre_activation = tf.nn.bias_add(conv, biases)
		# 使用ReLU激活函数
		conv1 = tf.nn.relu(pre_activation, name= scope.name)
		# conv1的局部响应归一化
		norm1 = tf.nn.lrn(conv1, depth_radius= 4, bias=1.0, alpha=0.001/9.0, 
		beta=0.75, name='norm1')
    
    # 池化层pool1
    with tf.variable_scope('pooling1') as scope:     
		# 使用最大池化
		pool1 = tf.nn.max_pool(norm1, ksize=[1,2,2,1], strides=[1,2,2,1],padding='SAME', name='pooling1')
		print ("pool1 img shape %s"%(pool1.shape))

    # 卷积层conv2
    with tf.variable_scope('conv2') as scope:  
		# 定义权值并初始化 
		weights = tf.get_variable('weights', shape= [3, 3, 64, 96], dtype= tf.float32,
		initializer= tf.truncated_normal_initializer(stddev= 0.01, dtype= tf.float32))
		# 定义偏执并初始化
		biases = tf.get_variable('biases', shape= [96], dtype= tf.float32, initializer=
		tf.constant_initializer(0.1))
		# 卷积运算
		conv = tf.nn.conv2d(pool1, weights, strides= [1,1,1,1], padding= 'SAME')
		print ("conv2 img shape %s"%(conv.shape))
		pre_activation = tf.nn.bias_add(conv, biases)
		# 使用ReLU激活函数
		conv2 = tf.nn.relu(pre_activation, name= 'conv2')
    
    # 池化层pool2
    with tf.variable_scope('pooling2_lrn') as scope:  
		# conv2的局部响应归一化
		norm2 = tf.nn.lrn(conv2, depth_radius= 4, bias=1.0, alpha=0.001/9.0, 
		beta=0.75, name='norm2')
		# 使用最大池化
		pool2 = tf.nn.max_pool(norm2, ksize=[1,2,2,1], strides=[1,2,2,1],padding='SAME', name='pooling2')
		print ("pool2 img shape %s"%(pool2.shape))
    
    # 卷积层conv3
    with tf.variable_scope('conv3') as scope:  
		# 定义权值并初始化 
		weights = tf.get_variable('weights', shape= [3, 3, 96, 256], dtype= tf.float32,
		initializer= tf.truncated_normal_initializer(stddev= 0.01, dtype= tf.float32))
		# 定义偏执并初始化
		biases = tf.get_variable('biases', shape= [256], dtype= tf.float32, initializer=
		tf.constant_initializer(0.1))
		# 卷积运算
		conv = tf.nn.conv2d(pool2, weights, strides= [1,1,1,1], padding= 'SAME')
		print ("conv3 img shape %s"%(conv.shape))
		pre_activation = tf.nn.bias_add(conv, biases)
		# 使用ReLU激活函数
		conv3 = tf.nn.relu(pre_activation, name= 'conv3')
    
    # 卷积层conv4
    with tf.variable_scope('conv4') as scope:  
		# 定义权值并初始化 
		weights = tf.get_variable('weights', shape= [3, 3, 256, 256], dtype= tf.float32,
		initializer= tf.truncated_normal_initializer(stddev= 0.01, dtype= tf.float32))
		# 定义偏执并初始化
		biases = tf.get_variable('biases', shape= [256], dtype= tf.float32, initializer=
		tf.constant_initializer(0.1))
		# 卷积运算
		conv = tf.nn.conv2d(conv3, weights, strides= [1,1,1,1], padding= 'SAME')
		print ("conv4 img shape %s"%(conv.shape))
		pre_activation = tf.nn.bias_add(conv, biases)
		# 使用ReLU激活函数
		conv4 = tf.nn.relu(pre_activation, name= 'conv4')
    
    # 卷积层conv5
    with tf.variable_scope('conv5') as scope:  
		# 定义权值并初始化 
		weights = tf.get_variable('weights', shape= [3, 3, 256, 120], dtype= tf.float32,
		initializer= tf.truncated_normal_initializer(stddev= 0.01, dtype= tf.float32))
		# 定义偏执并初始化
		biases = tf.get_variable('biases', shape= [120], dtype= tf.float32, initializer=
		tf.constant_initializer(0.1))
		# 卷积运算
		conv = tf.nn.conv2d(conv4, weights, strides= [1,1,1,1], padding= 'SAME')
		print ("conv5 img shape %s"%(conv.shape))
		pre_activation = tf.nn.bias_add(conv, biases)
		# 使用ReLU激活函数
		conv5 = tf.nn.relu(pre_activation, name= 'conv5')

    # 池化层pool5
    with tf.variable_scope('pooling6') as scope:     
		# 使用最大池化
		pool6 = tf.nn.max_pool(conv5, ksize=[1,2,2,1], strides=[1,2,2,1],padding='SAME', name='pooling6')
		print ("pooling5 img shape %s"%(pool6.shape))
    
    # 全连接层local6
    with tf.variable_scope('local7') as scope:
		reshape = tf.reshape(pool6, shape=[batch_size, -1])
		print reshape.shape
		dim = reshape.get_shape()[1].value 
		# 定义权值并初始化 
		weights = tf.get_variable('weights', shape= [4*4*120, 256], dtype= tf.float32,
		initializer= tf.truncated_normal_initializer(stddev= 0.005, dtype= tf.float32))
		# 定义偏执并初始化
		biases = tf.get_variable('biases', shape= [256], dtype= tf.float32, initializer=
		tf.constant_initializer(0.0))
		local7 = tf.nn.relu(tf.matmul(reshape, weights) + biases, name=scope.name)
		print ("fc6 img shape %s"%(local7.shape))
		# 使用丢失输出技巧
		local7 = tf.nn.dropout(local7, keep_prob=0.5)
    
    # 全连接层local7
    with tf.variable_scope('local8') as scope:
		# 定义权值并初始化 
		weights = tf.get_variable('weights', shape= [256, 256], dtype= tf.float32,
		initializer= tf.truncated_normal_initializer(stddev= 0.005, dtype= tf.float32))
		# 定义偏执并初始化
		biases = tf.get_variable('biases', shape= [256], dtype= tf.float32, initializer=
		tf.constant_initializer(0.1))
		local8 = tf.nn.relu(tf.matmul(local7, weights) + biases, name='local8')
		print ("fc7 img shape %s"%(local8.shape))
		# 使用丢失输出技巧
		local8 = tf.nn.dropout(local8, keep_prob=0.5)
    
    # 线性软最大输出层
    with tf.variable_scope('softmax_linear') as scope:
		# 定义权值并初始化 
		weights = tf.get_variable('softmax_linear', shape= [256, n_classes], dtype= tf.float32,
		initializer= tf.truncated_normal_initializer(stddev= 0.005, dtype= tf.float32))
		# 定义偏执并初始化
		biases = tf.get_variable('biases', shape= [n_classes], dtype= tf.float32, initializer=
		tf.constant_initializer(0.0))
		softmax_linear = tf.add(tf.matmul(local8, weights), biases, name='softmax_linear')
		print ("output img shape %s"%(softmax_linear.shape))
		return softmax_linear
    
# 定义损失函数
def losses(logits, labels):
    with tf.variable_scope('loss') as scope:
		cross_entropy = tf.nn.sparse_softmax_cross_entropy_with_logits(logits= logits,
		labels= labels, name= 'xentropy_per_example')
		# 计算张量的平均值
		loss = tf.reduce_mean(cross_entropy, name= 'loss')
		print type(loss)
		# 对loss汇总和记录
		#tf.summary.scalar(scope+'/loss', loss)
    return loss

# 定义训练函数
def trainning(loss, learning_rate):
    with tf.name_scope('optimizer'):
        # 使用Adam优化器
        optimizer = tf.train.AdamOptimizer(learning_rate= learning_rate)
        # 初始化global_step为0
        global_step = tf.Variable(0, name='global_step', trainable=False)
        # 更新参数最小化损失
        train_op = optimizer.minimize(loss, global_step= global_step)
    return train_op

# 定义评估函数，计算准确率
def evaluation(logits, labels):
    with tf.variable_scope('accuracy') as scope:
        # 判断标记是否在前k个预测中，返回bool型Tensor
        correct = tf.nn.in_top_k(logits, labels, 1)
        # 将bool型数据转换为float16
        correct = tf.cast(correct, tf.float16)
        # 通过计算correct的均值得到准确率
        accuracy = tf.reduce_mean(correct)
        # 对准确率数据进行汇总
        tf.summary.scalar(scope.name+'/accuracy', accuracy)
    return accuracy


 


