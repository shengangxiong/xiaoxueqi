#-*- encoding: UTF-8 -*-
import model 
import os 
import cifar10_input
import tensorflow as tf
import numpy as np
import sys
import matplotlib.pyplot as plt
import cv2

batch_size = 50
val_batch_size=50
data_dir = 'cifar10_data/cifar-10-batches-bin'
print("begin")
images_train, labels_train = cifar10_input.distorted_inputs(data_dir = data_dir, batch_size = batch_size)
images_test, labels_test = cifar10_input.distorted_inputs(data_dir = data_dir, batch_size = batch_size)
print("begin data")
#print type(images_train[0])
print images_train.shape


N_CLASSES =10 
IMG_W = 32 
IMG_H = 32 
#VAL_BATCH_SIZE = 32 
MAX_STEP = 450000 
learning_rate = 0.0001 

logs_train_dir="logs"
model_path = "conv_module/CNNmodel.ckpt"

def run_training(logs_train_dir_str,opt):
	logits = model.inference(images_train, batch_size, N_CLASSES)#定义网络模型
	loss = model.losses(logits, labels_train) # 计算训练batch的损失
	train_op = model.trainning(loss, learning_rate) # 利用损失和学习率更新参数
	acc = model.evaluation(logits, labels_train) # 计算准确率


	x_train = tf.placeholder(tf.float32, shape=[batch_size, IMG_W, IMG_H, 3])
	y_train_ = tf.placeholder(tf.int16, shape=[batch_size])
	x_val = tf.placeholder(tf.float32, shape=[val_batch_size, IMG_W, IMG_H, 3])
	y_val = tf.placeholder(tf.int16, shape=[val_batch_size])
	saver = tf.train.Saver()
	if opt:
		with tf.Session() as sess:
		    sess.run(tf.global_variables_initializer())     # 运行初始化
		    coord = tf.train.Coordinator()                  # 设置多线程协调器
		    threads = tf.train.start_queue_runners(sess= sess, coord=coord)  # 开始队列运行器(Queue Runner)
		    summary_op = tf.summary.merge_all()     # 汇总操作
		    train_writer = tf.summary.FileWriter(logs_train_dir_str, sess.graph)    # 把训练的汇总写入logs_train_dir
		    val_writer = tf.summary.FileWriter(logs_train_dir_str, sess.graph)    # 把测试的汇总写入logs_val_dir
		    try:
		        for step in np.arange(MAX_STEP):
					if coord.should_stop():
						break
					tra_images, tra_labels = sess.run([images_train, labels_train])
					_, tra_loss, tra_acc = sess.run([train_op, loss, acc], feed_dict={x_train:tra_images,
					y_train_:tra_labels})
					if step % 50 == 0:
						print('Step %d, train loss = %.2f, train accuracy = %.2f%%'%(step, tra_loss, tra_acc*100.0))
						summary_str = sess.run(summary_op)
						train_writer.add_summary(summary_str, step)
					'''
					if step % 200 == 0 or (step +1) == MAX_STEP:
						val_images, val_labels = sess.run([val_batch, val_label_batch])
						val_loss, val_acc = sess.run([loss, acc], feed_dict={x_val:val_images, y_val_:val_labels})
						print('** Step %d, val loss = %.2f, val accuracy = %.2f%%**' %(step, val_loss, val_acc*100.0))
						summary_str = sess.run(summary_op)
						val_writer.add_summary(summary_str, step)
					'''
					if step % 2000 == 0 or (step +1) == MAX_STEP:
						checkpoint_path = os.path.join(logs_train_dir_str, 'model.ckpt')
						saver.save(sess, checkpoint_path, global_step=step)
		    except tf.errors.OutOfRangeError:
		        print('Done training -- epoch limit reached')
		    finally:
		        coord.request_stop()
		        coord.join(threads)
		    save_path = saver.save(sess, model_path)
		    print("Model saved in file: %s" % save_path)
	else:
		print "test model!"
		with tf.Session() as sess:
			# Initialize variables
			sess.run(tf.global_variables_initializer())
			# Restore model weights from previously saved model
			saver.restore(sess, model_path)
			coord = tf.train.Coordinator()                  # 设置多线程协调器
			threads = tf.train.start_queue_runners(sess= sess, coord=coord)  # 开始队列运行器(Queue Runner)
			image_batch, label_batch = sess.run([images_test, labels_test])
			print sess.run(logits, feed_dict={x_train:image_batch})
			
			for i in range(batch_size):
				plt.imshow(image_batch[i])
				plt.show()
				print(label_batch[i])
			#coord.request_stop()
			#coord.join(threads)


if __name__ == "__main__":
    if sys.argv[1] == '-train':
        opt = True
    elif sys.argv[1] == '-test': 
        opt = False
    run_training(logs_train_dir,opt)

            




