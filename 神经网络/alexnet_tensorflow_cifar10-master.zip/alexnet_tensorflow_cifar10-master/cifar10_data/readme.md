#store cifar10 data
