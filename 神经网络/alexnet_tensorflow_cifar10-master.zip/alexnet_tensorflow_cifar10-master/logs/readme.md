#store tensorboard imformation
