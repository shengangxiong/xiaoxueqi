from db.coco import MSCOCO 

datasets = {
    "MSCOCO": MSCOCO
}
